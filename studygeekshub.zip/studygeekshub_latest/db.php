<?php
  
   $conn = mysqli_connect ("localhost","root","","login");
   
   if (mysqli_connect_errno($conn))
{
print "unable to connect:".mysqli_connect_errno();
	
}
?>
