<!DOCTYPE html>
<?php require_once('metafile.php'); ?>
<?php require_once('header.php'); ?><!-- #header end -->
		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">
				<div class="heading-block center">
							<h2>DEPARMENTS</h2>
							<span>We provide a Study Materials of different Courses &amp; Branch</span>
						</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
                            <h3><a href="IT_course.php">IT</a></h3>
                            <br>
                            BCA
                            <br>
                            MCA
                            <br>
                            BSC(Coumpter Science)
                            <br>
                            BSC(Information Technology)
                            <br>
                            MSC(Coumpter Science)
                            <br>
                            MSC(Information Technology)
                            <br>
                            BSC(Biotechnology)
                            <br>
                            MSC(Biotechnology)
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3><a href="">ENGINEERING</a></h3>
							<br>
                            Electronics and Communications Engineering (ECE)
                            <br>
                            Computer Science and Engineering (CSE)
                            <br>
                            Mechanical Engineering (ME)
                            <br>
                            Civil Engineering (CE)
                            <br>
                            Electrical and Electronics Engineering (EEE)
                            <br>
                            Chemical Engineering (CHE)
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Commerce</a></h3>
							<br>
                            B.Com
                            <br>
                            B.Com (Professional)
                            <br>
                            B.Com. (Management Accounting and International Finance )
                            <br>
                            M.Com
                            <br>
                            BBA
                            <br>
                            MBA 
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-stack i-alt"></i></a>
							</div>
							<h3><a href="">LAW</a></h3>
							<br>
                            B.A
                            <br>
                            B.Com
                            <br>
                            BBA
                            <br>
                            LL.B.
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Physical Education</a></h3>
							<br>
                            B.Sc. (Physical_Education,
                                 Health Education and Sports)
                            <br>
                            Bachelor of Physical Education & Sports(BPES)
                            <br>
                            Diploma in Yoga
                            <br>
                            Diploma in Physical Education (D.P.ED.)
                            <br>
                            <br>
                            <br>
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">FINE ARTS</a></h3>
							<br>
                            B.A. (Fine Arts)
                            <br>
                            Bachelor of Fine Arts (BFA)
                                                        
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Fashion Design</a></h3>
							<br>
                            B.Sc. (Design - Fashion)
                            <br>
                            Diploma in Fashion(Women Wear)
                            <br>
                            Diploma in Styling & Grooming
                            <br>
                            B.Design (Fashion)
                            <br>
                            <br>
                            <br>
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Multimedia and Animation</a></h3>
							<br>
                            B.Sc. (Design - Multimedia)
                            <br>
                            B.Sc. (Design - Grphics)
                            <br>
                            B.Sc. (Design - Gaming)
                            <br>
                            B.Design (Multimedia)
                            <br>
                            B.Design (Graphics)
						</div>
					</div>
                    <div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">Hotel Management and Tourism</a></h3>
							<br>
                            B.Sc. (Hotel Management)
                            <br>
                            Bachelor of Hotel Mgt. and Catering Technology (BHMCT)
                            <br>
                            B.Sc. (Airlines, Tourism and Hospitality)
                            <br>
                            Diploma in Airline Cabin Crew and Hospitality
                                                                                    
						</div>
					</div>
                    
                        
					<div class="clear"></div><div class="line"></div>

					
				</div>
 					
			</div>

		</section><br><br><!-- #content end -->
        
		<?php require_once('footer.php'); ?>
</body>
</html>