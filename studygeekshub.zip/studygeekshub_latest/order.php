
<!DOCTYPE html>
<html>


   <script type='text/javascript'>   
function validateMyForm()
 
    { 
        var valid = true; 
        var validationMessage = 'Please correct the following errors:\r\n';
         if (document.getElementById('register-form-name').value.length == 0)
 
        {
 
            validationMessage = validationMessage + '  - Name is missing\r\n';
 
            valid = false;
 
        }

         if (document.getElementById('register-form-email').value.length == 0)
 
        {
 
            validationMessage = validationMessage + '  - email is missing\r\n';
 
            valid = false;
 
        }

         if (document.getElementById('register-form-username').value.length == 0)
 
        {
 
            validationMessage = validationMessage + '  - username is missing\r\n';
 
            valid = false;
 
        }
       

         if (document.getElementById('register-form-phone').value.length == 0)
 
        {
 
            validationMessage = validationMessage + '  - phone is missing\r\n';
 
            valid = false;
 
        }

       
         if (document.getElementById('register-form-password').value.length == 0)
 
        {
 
            validationMessage = validationMessage + '  - password is missing\r\n';
 
            valid = false;
 
        }


if(document.getElementById('register-form-password').value != document.getElementById('register-form-repassword').value) 
        { 

        validationMessage = validationMessage + '  - Please enter same password\r\n';
            valid = false;
        }

        if (valid == false) 
        {
 
            alert(validationMessage);
            return false;
 
        }

        else

{
	return true;
}
        
       
    }
</script> 

<?php require_once('header.php'); ?>

		<!-- Page Title
		============================================= -->
		

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="tabs divcenter nobottommargin clearfix" id="tab-login-register" style="max-width: 500px;">

						<ul class="tab-nav tab-nav2 center clearfix">
                            
                            <li class="inline-block"><a href="#tab-register">Order</a></li>
                        </ul>

						<div class="tab-container">

							 <div class="tab-content clearfix" id="tab-register">
                                <div class="panel panel-default nobottommargin">
                                    <div class="panel-body" style="padding: 40px;">
                                        <h3>Make Order</h3>

                                        <form id="register-form" name="register-form" class="nobottommargin" action="signup.php" method="post" enctype="multipart/form-data" onsubmit="return validateMyForm() ">

                                            <div class="col_full">
                                                <label for="register-form-name"><span style="color:red">*</span>Name:</label>
                                                <input type="text" id="register-form-name" name="register-form-name" value="" class="form-control" />
                                            </div>

                                            <div class="col_full">
                                                <label for="register-form-email"><span style="color:red">*</span>Email Address:</label>
                                                <input type="email" id="register-form-email" name="register-form-email" value=""  class="form-control" />
                                            </div>

                                    
                                            <div class="col_full">
                                                <label for="register-form-phone"><span style="color:red">*</span>Phone:</label>
                                                <input type="text" id="register-form-phone" name="register-form-phone" value="" required-placeholder="Enter a valid Phone" class="form-control" />
                                            </div>
                                
                                            
                                            <div class="col_full">
                                                <label for="product_name"><span style="color:red">*</span>Product Name:</label>
                                                <input type="text" id="product_name" name="product_name" value="" required-placeholder="Enter a Product Name" class="form-control" />
                                            </div>

                                            <div class="col_full">
                                                <label for="product_quantity"><span style="color:red">*</span>Quantity:</label>
                                                <input type="text" id="product_quantity" name="product_quantity" value="" class="form-control" />
                                                <div class="col_full" > 
                                                </div>
                                                <div>

                                            
                                            <br>
                                                <button class="button button-3d button-black nomargin" id="register-form-submit" name="register-form-submit" value="register" onclick="validateMyForm(); ">Order Now</button>
                                            </div>
                                            
                                        </form>
                                        <script type="text/javascript">
                                            $('#register-form').submit(validateMyForm())

                                        </script>
									</div>
								</div>
							</div>

						</div>

					</div>

				</div>

			</div>

		</section><!-- #content end -->
<?php require_once('footer.php'); ?>

</body>
</html>
 
