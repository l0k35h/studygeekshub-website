  <?php
$file = 'E:\php\studygeekshub_latest\programming_in_c_it/CAP100-Lec#4.pdf';
$filename = 'CAP100-Lec#4.pdf';
header('Content-type: application/pdf');
header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: ' . filesize($file));
header('Accept-Ranges: bytes');
@readfile($file);

                    ?>