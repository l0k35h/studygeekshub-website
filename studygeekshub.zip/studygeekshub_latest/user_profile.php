
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<?php
$conn=mysqli_connect("localhost","root","","login");
?>
<head>
	<title> Profile </title>
	<?php require_once('header.php'); ?>

		<title> Profile </title>
	<link href="css/style.css" rel='stylesheet' type='text/css'/>
	<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,400" rel="stylesheet">
	

	
</head>

<body>
	<h1> Profile </h1>
		<div class="main-agileits">
		<div class="right-wthree">
		<h2>
				<?php
				echo $user;
				 ?></h2><?php
		$sql="SELECT * FROM user_data WHERE Username='$user'";
$result=$conn->query($sql);
$row=$result->fetch_all();
$counter=$result->num_rows;?>
<?php foreach ($row as $key ) : ?>
	
<?php
echo '<img src="data:image/jpeg;base64,'.base64_encode( $key[5] ).'"/>';  

?> 

<?php endforeach; ?>

				
			</div>
			<div class="left-w3ls">
			<ul class="address">
													<p> <li>
														<ul class="address-text">
															<li><b>PHONE:</b></li>
															<li> <?php
															 $row=$conn->query("select Phone from user_data where Username='$user'");
   																list($phone)=$row->fetch_row();
  															 echo $phone;
														?>
															</li>
														</ul>
													</li></p>
													<li>
														<ul class="address-text">
															<li><b>NAME :</b></li>
															<li><?php
															 $row=$conn->query("select Name from user_data where Username='$user'");
   																list($name)=$row->fetch_row();
  															 echo $name;
														?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>E-MAIL :</b></li>
															<li><?php
															 $row=$conn->query("select Email from user_data where Username='$user'");
   																list($email)=$row->fetch_row();
  															 echo $email;
														?></li>
														</ul>
													</li>	
													<li>
														<ul class="address-text">
															<li><b>NATION :</b></li>
															<li><?php
															 $row=$conn->query("select country from user_data where Username='$user'");
   																list($country)=$row->fetch_row();
  															 echo $country;
														?></li>
														</ul>
													</li>												
												</ul>
												<form action='user_dashboard.php'>
				<button class="button button-3d button-gray nomargin" >Go Back</button>
				</form>
						
	<!-- //pop-up-box -->
					
			</div>
			
			<div class="clear"></div>
		</div>
		<?php require_once('footer.php'); ?>
</body>
</html>