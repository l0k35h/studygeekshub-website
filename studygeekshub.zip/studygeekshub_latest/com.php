<html>
     <?php require_once('header.php'); ?>

     <section id="page-title">
          

               <div class="container clearfix" >
                    <h1>COMMUNITY</h1>
                    <span>Let's group up..</span>
                    
               </div>

          </section>


     	<div class="container-fluid">
     	<div class="container col-md-9">
                                   
                                   <div class="heading-block">
                                   <h2>this is community topic</h2>
                                   <span>This topic is all about blah blah blah &amp; Blah</span>
                                   
                                   <ul class="entry-meta clearfix">
                                             <li><i class="icon-calendar3"></i> 10th February 2014</li>
                                             <li><a href="#"><i class="icon-user"></i> admin</a></li>
                                             <li><i class="icon-folder-open"></i> <a href="#">General</a>, <a href="#">Media</a></li>
                                             <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13 Comments</a></li>
                                             <li><a href="#"><i class="icon-camera-retro"></i></a></li>
                                        </ul><br>
                                                                                <div class="entry-content">
                                             <p>here we will wright about the topic  here we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topic</p>

                                             <table class="table table-striped">
               
                                             <tbody>
                                             <tr><td>post 1</td></tr>
                                             <tr><td>post 2</td></tr>
                                             <tr><td>post 3</td></tr>
                                             <tr><td>post 3</td></tr>
                                             </tbody>
                                             </table>
                                               <a href="#.html" class="more-link">Read More</a>
                                             </div>
                                             </div>    
                                             <div class="heading-block">
                                   <h2>this is community topic</h2>
                                   <span>This topic is all about blah blah blah &amp; Blah</span>
                                   
                                   <ul class="entry-meta clearfix">
                                             <li><i class="icon-calendar3"></i> 10th February 2014</li>
                                             <li><a href="#"><i class="icon-user"></i> admin</a></li>
                                             <li><i class="icon-folder-open"></i> <a href="#">General</a>, <a href="#">Media</a></li>
                                             <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13 Comments</a></li>
                                             <li><a href="#"><i class="icon-camera-retro"></i></a></li>
                                        </ul><br>
                                                                                <div class="entry-content">
                                             <p>here we will wright about the topic  here we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topic</p>

                                             <table class="table table-striped">
               
                                             <tbody>
                                             <tr><td>post 1</td></tr>
                                             <tr><td>post 2</td></tr>
                                             <tr><td>post 3</td></tr>
                                             <tr><td>post 3</td></tr>
                                             </tbody>
                                             </table>
                                               <a href="#.html" class="more-link">Read More</a>
                                             </div>
                                             </div>     

                                             <div class="heading-block">
                                   <h2>this is community topic</h2>
                                   <span>This topic is all about blah blah blah &amp; Blah</span>
                                   
                                   <ul class="entry-meta clearfix">
                                             <li><i class="icon-calendar3"></i> 10th February 2014</li>
                                             <li><a href="#"><i class="icon-user"></i> admin</a></li>
                                             <li><i class="icon-folder-open"></i> <a href="#">General</a>, <a href="#">Media</a></li>
                                             <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13 Comments</a></li>
                                             <li><a href="#"><i class="icon-camera-retro"></i></a></li>
                                        </ul><br>
                                                                                <div class="entry-content">
                                             <p>here we will wright about the topic  here we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topichere we will wright about the topic</p>

                                             <table class="table table-striped">
               
                                             <tbody>
                                             <tr><td>post 1</td></tr>
                                             <tr><td>post 2</td></tr>
                                             <tr><td>post 3</td></tr>
                                             <tr><td>post 3</td></tr>
                                             </tbody>
                                             </table>
                                               <a href="#.html" class="more-link">Read More</a>
                                             </div>
                                             </div>             


     		                       






     	</div>
     	<div class="col-md-3">
     		

     	<div class="alert alert-info text-center"><h3>side bar</h3></div>



     	</div>



     	</div>


<?php require_once('footer.php'); ?>

</html>