<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>


		<!-- Page Title
		============================================= -->
	<section id="page-title">
		

			<div class="container clearfix">
				<h1>MCQ</h1>
				<span>Test Yourself to be proud...</span>
				
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->

		<div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Programming</a>
        </h4>
      </div>
      <div id="collapseOne" class="panel-collapse collapse in">
        <div class="panel-body"><a href=""><div>C++ Programming</div></a></div>
        
        <div class="panel-footer"><a href=""><div>C# Programming</div></a></div>
        <div class="panel-footer"><a href=""><div>JAVA Programming</div></a></div>

      </div>
    </div>
  </div>
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="col_full clearfix">

						<h3>Programming</h3>

						<p style="font-size: 14px; line-height: 22px;"><img src="programming_mcq.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounce" />
                        <a href="c_programming.php"><div>C Programming</div></a>
                            <br>
                            <a href=""><div>C++ Programming</div></a>
                            <br>
                            <a href=""><div>C# Programming</div></a>
                            <br>
                            <a href=""><div>JAVA Programming</div></a>
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Verbal and Reasoning</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="verbal_mcq.jpg" class="alignleft notopmargin" alt="Image" title="Image" data-animate="flash" />
                            <a href=""><div>Verbal Ability</div></a>
                            <br>
                            <a href=""><div>Logical Reasoning</div></a>
                            <br>
                            <a href=""><div>Verbal Reasoning</div></a>
                            <br>
                            <a href=""><div>Non Verbal Reasoning</div></a>
                            
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Online Test</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="online_mcq.jpg" class="alignright notopmargin" alt="Image" title="Image" data-animate="pulse" />
                        <a href=""><div>Aptitude Test</div></a>
                            <br>
                            <a href=""><div>Verbal Ability Test</div></a>
                            <br>
                            <a href=""><div>C Programming Test</div></a>
                            <br>
                            <a href=""><div>Java Programming Test</div></a>
                            
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Interview </h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="shake" />
                        <a href=""><div>Placement Papers</div></a>
                            <br>
                            <a href=""><div>Group Discussion</div></a>
                            <br>
                            <a href=""><div>HR Interview</div></a>
                            <br>
                            <a href=""><div>Technical Interview</div></a>
                            
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="swing" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="tada" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="wobble" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="bounceIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounceInDown" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image"  data-animate="bounceInLeft"/>Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Bounce-In-Right Animation</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounceInRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="bounceInUp" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInDown" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeInDownBig" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeInRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInRightBig" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeInUp" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInUpBig" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="flip" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="flipInX" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="flipInY" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="lightSpeedIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="slideInRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="slideInLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="slideInDown" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="rotateInUpRight"  />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="rotateInUpLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="rotateInDownRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="rotateInDownLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="rotateIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="rollIn" />Data will update soon.</p>

					</div>

					<div class="col_full nobottommargin clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeIn" data-delay="3000" />Data will update soon.</p>

					</div>

				</div>

			</div>

		
		</section>
		<?php require_once('footer.php'); ?>
</body>
</html>