﻿
<html>
<?php require_once('metafile.php'); ?>
     <?php require_once('header.php'); ?>
     
 
     <div class="container clearfix">
					<div class="slider-caption slider-caption-center">
						<h2 >studyGeeks</h2>
		<p data-animate="fadeInUp" data-delay="400">Smart Study at your Screen!!</p>
						<form action="search.php" method="get" role="form" class="nobottommargin">
							<div class="input-group input-group-lg">
								<input type="text" name="q" class="form-control"  placeholder="Type &amp; Hit Enter..">
								<span class="input-group-btn">
									<button class="btn btn-danger" type="submit" >Search</button>
								</span>
							</div>
						</form>
</div></div>
		<section id="slider" class="slider-parallax swiper_wrapper full-screen clearfix">

			<div class="slider-parallax-inner">

				<div class="swiper-container swiper-parent">
					<div class="swiper-wrapper">
						<div class="swiper-slide dark" style="background-image: url('images/img.jpeg');">
						
						<div class="swiper-slide dark" style="background-image: url('images/img2.jpeg');">
						
						<div class="swiper-slide" style="background-image: url('images/img3.jpeg'); background-position: center top;">
							
						</div>
					</div>
					<div id="slider-arrow-left"><i class="icon-angle-left"></i></div>
					<div id="slider-arrow-right"><i class="icon-angle-right"></i></div>
					
				</div>

			</div>

		</section>
		

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">
				<div class="heading-block center">
							<h2>DEPARMENTS</h2>
							<span>We provide a Study Materials of different Courses &amp; Branch</span>
						</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
							<h3>IT</h3>
							<p>Information technology (IT) is the application of computers to store, study, retrieve, transmit, and manipulate data, or information, often in the context of a business or other enterprise. IT is considered a subset of information and communications technology (ICT).</p>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3>ENGINEERING</h3>
							<p>the branch of science and technology concerned with the design, building, and use of engines, machines, and structures.</p>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3>BIOTECHNOLOGY</h3>
							<p>the exploitation of biological processes for industrial and other purposes, especially the genetic manipulation of microorganisms for the production of antibiotics, hormones.</p>
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-stack i-alt"></i></a>
							</div>
							<h3>LAW</h3>
							<p>Law is study of the system of rules that are created and enforced through social or governmental institutions to regulate behavior..</p>
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3>AGRICULTURE</h3>
							<p>This branch deals with study of the science or practice of farming, including cultivation of the soil for the growing of crops and the rearing of animals to provide food, wool, and other products..</p>
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3>FINE ARTS</h3>
							<p>It's the study of creative art, especially visual art whose products are to be appreciated primarily or solely for their imaginative, aesthetic, or intellectual content.</p>
						</div>
					</div>

					

					<div class="clear"></div><div class="line"></div>

					
				</div>
 					
			</div>

		</section><br><br><!-- #content end -->


		<section id="content">

			<div class="content-wrap">

				
				<div class="section">

					<div class="container clear-bottommargin clearfix">

						<div class="heading-block center">
							<h2>FEATURE</h2>
							<span>Learn Smartly &amp; Become Smart</span>
						</div>

						<div class="row">

							<div class="col-md-4 bottommargin">
								<img data-animate="fadeInLeftBig" src="images/new/11.jpg" alt="iPhone" class="center-block">
							</div>

							<div class="col-md-4 col-sm-6 topmargin bottommargin">

								<div class="col_full">

									<div class="feature-box fbox-plain fbox-small fbox-dark">
										<div class="fbox-icon">
											<a href="#"><i class="icon-line-monitor"></i></a>
										</div>
										<h3>PPTs</h3>
										<p>Wide collection of ppts from different courses covering different topics.<br>Download them now.</p>
									</div>

								</div>

								<div class="col_full">

									<div class="feature-box fbox-plain fbox-small fbox-dark">
										<div class="fbox-icon">
											<a href="#"><i class="icon-line-eye"></i></a>
										</div>
										<h3>COMMUNITY</h3>
										<p>Group of many readers making discussion about hot topics.<br>Start new topic or be part of old one</p>
									</div>

								</div>

								<div class="col_full nobottommargin">

									<div class="feature-box fbox-plain fbox-small fbox-dark">
										<div class="fbox-icon">
											<a href="#"><i class="icon-line-power"></i></a>
										</div>
										<h3>VIDEOS</h3>
										<p>Collection of tutrials for better understanding &amp; learning.<br>
										Get your personal tutor at home. </p>
									</div>

								</div>

							</div>

							<div class="col-md-4 col-sm-6 topmargin bottommargin">

								<div class="col_full">

									<div class="feature-box fbox-plain fbox-small fbox-dark">
										<div class="fbox-icon">
											<a href="#"><i class="icon-line-layers"></i></a>
										</div>
										<h3>MCQ</h3>
										<p>Test your knowleage with wide rande of multiple choice questions.
										</p>
									</div>

								</div>

								<div class="col_full">

									<div class="feature-box fbox-plain fbox-small fbox-dark">
										<div class="fbox-icon">
											<a href="#"><i class="icon-line-star"></i></a>
										</div>
										<h3>FUTURE</h3>
										<p>The topics which going to be get important in future.<b>
										Be Updated.</p>
									</div>

								</div>

								<div class="col_full nobottommargin">

									<div class="feature-box fbox-plain fbox-small fbox-dark">
										<div class="fbox-icon">
											<a href="#"><i class="icon-line-anchor"></i></a>
										</div>
										<h3>JOIN US</h3>
										<p>For better learning experience &amp; share your knowleage with other readers. </p>
									</div>

								</div>

							</div>

						</div>

					</div>

				</div>

				

		</section>
		<div class="col_full bottommargin-lg common-height">

					<div class="col-md-4 dark col-padding ohidden" style="background-color: #1abc9c;">
						<div>
							<h3 class="uppercase" style="font-weight: 600;">Why choose Us</h3>
							<p style="line-height: 1.8;">
								Immense Capabilities<br>
								Multilingual Localisation solutions<br>
								Happy Learning<br>
								Credible Course Library<br>
								Rich Legacy<br>
							</p>
							<a href="#" class="button button-border button-light button-rounded button-reveal tright uppercase nomargin"><i class="icon-angle-right"></i><span>Read More</span></a>
							<i class="icon-bulb bgicon"></i>
						</div>
					</div>

					<div class="col-md-4 dark col-padding ohidden" style="background-color: #34495e;">
						<div>
							<h3 class="uppercase" style="font-weight: 600;">Our Mission</h3>
							<p style="line-height: 1.8;">
								To be a dynamic, vibrant &amp; value-based global website which centred around customer, employee &amp; societal readers &amp; learners.
							</p>
							<a href="#" class="button button-border button-light button-rounded uppercase nomargin">Read More</a>
							<i class="icon-cog bgicon"></i>
						</div>
					</div>

					<div class="col-md-4 dark col-padding ohidden" style="background-color: #e74c3c;">
						<div>
							<h3 class="uppercase" style="font-weight: 600;">What you get</h3>
							<p style="line-height: 1.8;">
								We help in Enhancing your skills &amp; improve knowledge base.<br>
								You can compete with self for creativity and innovation.<br>
								We Exceed your expectations in providing high-quality solutions.
							</p>
							<a href="#" class="button button-border button-light button-rounded uppercase nomargin">Read More</a>
							<i class="icon-thumbs-up bgicon"></i>
						</div>
					</div>

					<div class="clear"></div>

				</div>


<?php require_once('footer.php'); ?>
</body>
</html>