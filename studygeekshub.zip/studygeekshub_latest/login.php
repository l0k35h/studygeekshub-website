<html>

	<head>
	<title>Login</title>

	</head>
	<body>
	
	<?php
	include 'db.php';

	$id = $_POST['username'];
    $pwd = $_POST['password'];

$sql= "SELECT * from user_data WHERE Username='$id' AND Password='$pwd'";
$result=$conn->query($sql);
if ($id=='lokesh' && $pwd=='1010' or $id=='nishant' && $pwd=='1010'or $id=='manish' && $pwd=='1010'or $id=='abhishek' && $pwd=='1010'or $id=='pawan' && $pwd=='1010')
{
	 session_start();
	  $_SESSION["Login"] = "YES";
	  $_SESSION["username"] = $id;
	  header("location:admin_dashbord.php");
}
elseif($row = $result->fetch_all())	 
	 {
	 
	// If correct, we set the session to YES
	  session_start();
	  $_SESSION["Login"] = "YES";
	  $_SESSION["username"] = $id;
	  header("location:user_dashboard.php");
	 
}
else {
	 
	// If not correct, we set the session to NO
	  
	  $_SESSION["Login"] = "NO";
	  
	 echo "<script>
	alert('Check login credentials !');
	window.location.href='registration.php';	
	</script>";
	}

$conn->close();
	?>

	</body>
	</html>S



	