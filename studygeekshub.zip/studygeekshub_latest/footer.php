<!-- Footer
		============================================= -->
<footer id="footer"  class="container-fluid text-center">
<div class="container">
<br><br>
	<p>The Ultimate Study Zone &nbsp; | <a href="#" style="color:#000000"> <b>&nbsp;© studygeekshub.com</b></a></p>
<div class="buttons">
  <a href="#"><img src="twitter.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="facebook.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="dribble.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="rss.png"></a><br>
</div>
 <div class="clear"></div>
</footer>
</div>

	<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/plugins.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="js/functions.js"></script>
