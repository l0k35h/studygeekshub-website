<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
 <title>The Ultimate Study Companion -  Studygeekshub</title>
 <meta name="description" content="studygeeks hub is  a website for E-learning. The website will provide
information as well as subject materials related to various courses or
streams. It has  an additional feature of community learning
where people can come together to discuss on a particular topic and
share their opinion. Community learning will also enhance the
knowledge and concepts of individual. The website will also provide a
platform for communication between students and experts.">
   <meta name="keywords" content="HTML,CSS,XML,JavaScript,MCQs,PPTs,PDFs,Community,Discussion,Forum,Programming,Engineering">
  <meta name="author" content="Nishant Maurya,Manish Tomar,Abhishek Thakur,Lokesh Pandey,Pawan Tiwari">
  <meta property="og:title" content="Studygeekshub">
  <meta name="robots" content="mcq">
  <meta property="og:site_name" content="studygeekshub">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="en_US">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  