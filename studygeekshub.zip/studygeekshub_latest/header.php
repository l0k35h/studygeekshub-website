<?php 
	session_start();
	if(isset($_SESSION['Login']))
	{
		$user=$_SESSION["username"];
	}
?>

<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
	 <link rel="shortcut icon" type="image/x-icon" href="image/favicon.png" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />

	<!-- Stylesheets
	============================================= -->
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="style.css" type="text/css" />
	<link rel="stylesheet" href="css/swiper.css" type="text/css" />
	<link rel="stylesheet" href="css/dark.css" type="text/css" />
	<link rel="stylesheet" href="css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="css/animate.css" type="text/css" />
	<link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
    <link rel="stylesheet" href="style_1.css" type="text/css" />
	<link rel="stylesheet" href="css/responsive.css" type="text/css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<!-- Document Title
	============================================= -->
	<title>main</title>

</head>

<body class="stretched">


	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<header id="header" class="full-header dark">

			<div id="header-wrap">

				<div class="container clearfix">

               <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="home.php" class="standard-logo" data-dark-logo="image/logo.png"><img src="image/logo.png" alt="Canvas Logo"></a>
						<a href="home.php" class="retina-logo" data-dark-logo="image/logo-dark@2x.png"><img src="image/logo@2x.png" alt="Canvas Logo"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
						<nav id="primary-menu">

						<ul>
							<li><a href="home.php"><div>Home</div></a>
								
							</li>
							<li><a href="course.php"><div>Courses</div></a>
								
							</li>
							
							<li class="mega-menu"><a href="mcq.php"><div>MCQ</div></a>
								
							</li>
							<li class="mega-menu"><a href="main_forum.php"><div>Community</div></a>
								
							</li>

							<?php if(isset($_SESSION['Login'])){echo "<li class='mega-menu'><a href="."'user_dashboard.php'".">Dashboard</a></li>";echo '<li class="mega-menu"> <a href="logout.php">Logout</a></li>';} else{echo '<li class="mega-menu"><a href="login_validate.php" ><div>Account</div></a></li>'; } ?>

							<li class="mega-menu"><a href="error.php"><div>About Us</div></a>
								
							</li>
						</ul>




						<!-- Top Search
						============================================= -->
						<div id="top-search">
							<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
							<form action="search.php" method="get">
								<input type="text" name="q" class="form-control"  placeholder="Type &amp; Hit Enter..">
							</form>
						
						</div><!-- #top-search end -->

					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->