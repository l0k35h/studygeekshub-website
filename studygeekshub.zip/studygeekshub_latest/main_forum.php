<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>

<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Welcome to our Community Portal!</h1>
  <p class="lead">
    Come, Join and Interact with the world of studyGEEKs.One destination for all your queries from various professionals,experts and lot more...
  </p>

      </div>
    </div>
    <br><br>
<center>
 <h2>Ongoing Discussions</h2>
</center>
<?php
$conn=mysqli_connect("localhost","root","","forum");
if (mysqli_connect_errno($conn))
{
print "unable to connect:".mysqli_connect_errno();
	
}
$sql="SELECT * FROM forum_question ";
// OREDER BY id DESC is order result by descending

$result=$conn->query($sql);
$row=$result->fetch_all();
$counter=$result->num_rows;


?>
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover table-condensed" width="90%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr class="row">
<td class="col" width="6%" align="center" bgcolor="#E6E6E6"><strong>#</strong></td>
<td class="col"  width="23%" align="center" bgcolor="#E6E6E6"><strong>Topic</strong></td>
<td class="col"  width="23%" align="center" bgcolor="#E6E6E6"><strong>Detail</strong></td>
<td class="col"  width="23%" align="center" bgcolor="#E6E6E6"><strong>Category</strong></td>
<td class="col"  width="23%" align="center" bgcolor="#E6E6E6"><strong>DateTime</strong></td>
<td class="col"  width="15%" align="center" bgcolor="#E6E6E6"><strong>Views</strong></td>
<td class="col"  width="13%" align="center" bgcolor="#E6E6E6"><strong>Replies</strong></td>

</tr>
</table>
</div>



<?php 
foreach ($row as $key ) : ?>
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover table-condensed">
<tr class="row">
<td class="col" width="6%" align="center" bgcolor="#FFFFFF"><?php echo $key[0]; ?></td>
<td class="col"  width="23%" bgcolor="#FFFFFF"><a href="view_topic.php"> <?php echo $key[1];?> </a></td>
<td class="col"  width="23%" align="center" bgcolor="#FFFFFF"><?php echo $key[2]; ?></td>
<td class="col"  width="15%" align="center" bgcolor="#FFFFFF"><?php echo $key[3]; ?></td>
<td class="col"  width="23%" align="center" bgcolor="#FFFFFF"><?php echo $key[4]; ?></td>
<td class="col"  width="23%" align="center" bgcolor="#FFFFFF"><?php echo $key[5]; ?></td>
<td class="col"  width="15%" align="center" bgcolor="#FFFFFF"><?php echo $key[6]; ?></td>
</tr>
</table>
</div>
<?php  endforeach; ?>


</section>


<center>
<button type="button" class="btn btn-success" onclick= "location.href='create_topic.php';">Start New Dicussion!</button>
</center> 
</table>
		

		<!-- Footer
		============================================= -->
<?php require_once('footer.php'); ?>

</body>
</html>
