<!DOCTYPE html>
<?php require_once('header.php'); ?><!-- #header end -->


		<!-- Page Title
		============================================= -->
		<section id="page-title">

			<div class="container clearfix">
				<h1>C Programming</h1>
				<span>Test Yourself to be proud...</span>
				
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="col_full clearfix">

						<h3>Declarations and Initializations</h3>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/cprogramming.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounce" />
                        <a href="Declarations_and_Initializations_page001.php"><div>Page 1</div></a>
                            <br>
                            <a href=""><div>Page 2</div></a>
                            <br>
                            <a href=""><div>Page 3</div></a>
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Control Instructions</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/cprogramming.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="flash" />
                            <a href=""><div>Page 1</div></a>
                            <br>
                            <a href=""><div>Page 2</div></a>
                            <br>
                            <a href=""><div>Page 3</div></a>
                            
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Expressions</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/cprogramming.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="pulse" />
                        
                            <a href=""><div>Page 1</div></a>
                            <br>
                            <a href=""><div>Page 2</div></a>
                            <br>
                            <a href=""><div>Page 3</div></a>
                            
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Floating Point Issues </h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/cprogramming.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="shake" />
                        <a href=""><div>Page 1</div></a>
                            <br>
                            <a href=""><div>Page 2</div></a>
                            <br>
                            <a href=""><div>Page 3</div></a>
                            
                        </p>

					</div>

					
				</div>

			</div>

		
		</section>
		<?php require_once('footer.php'); ?>
</body>
</html>