<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>
<head>
<title>upload data</title>
</head>
<body>

    		<section>

			<div class="container clearfix" >
				<h1>Upload</h1>
				<span>Do some changes...</span>
				
			</div>

		</section>

    <form id="form1" name="form1" method="post" action="upload_ppt.php" enctype="multipart/form-data">

<td>
<table class="table table-striped table-bordered table-hover table-condensed"bgcolor="#FFFFFF">
<tr>
<td colspan="3" bgcolor="#E6E6E6"><center><strong>Create New Topic</strong></center> </td>
</tr>
<tr>
<td width="14%"><strong>Enter description about your file</strong></td>
<td width="2%">:</td>
<td width="84%"><input name="topic" type="text" id="topic" size="50" /></td>
</tr>
<tr><td>	
<strong>Select File::</strong></td>
<td>:</td>
<td><input type="file" name="description_entered2" align="center"><br></td>
</tr>
</div>
<td>&nbsp;</td>
<td>&nbsp;</td>

<td><input type="submit"  value="submit" name="submit" /> 

<input type="reset" name="Submit2" value="Reset" /></td>
</tr>
</table>
</td>


</form>

    


<form id="form1" name="form1" method="post" action="mcq_upload.php" enctype="multipart/form-data">
<table class="table table-striped table-bordered table-hover table-condensed"bgcolor="#FFFFFF">
<tr>
<td colspan="3" bgcolor="#E6E6E6"><center><strong>Create New Topic</strong></center> </td>
</tr>
<tr>
<td width="14%"><strong>Select Topic</strong></td>
<td width="2%">:</td>
<td width="84%"><select onchange="fetch_select(this.value);">
                <option value="" selected>Select Topic...</option>
                <option value="" > Topic1...</option>
                <option value="" > Topic2...</option>
                <option value="" > Topic3...</option>
            </select>
    <strong>Add New Topic ::</strong><input type="text" name="new_topic">
        <input type="submit" name="new_topic"  value="create">
    </td>
</tr>
<tr><td>	
<strong>Select Subject</strong></td>
<td>:</td>
<td><select onchange="fetch_select(this.value);">
                <option value="" selected>Select Subject...</option>
                <option value="" > subject1...</option>
                <option value="" > subject2...</option>
                <option value="" > subject3...</option>
            </select><br></td>
</tr>
<tr><td>	
<strong>Select Chapter</strong></td>
<td>:</td>
<td><select onchange="fetch_select(this.value);">
                <option value="" selected>Select chapter...</option>
                <option value="" > chapter1...</option>
                <option value="" > chapter2...</option>
                <option value="" > chapter3...</option>
            </select><br></td>
</tr>
  <tr>
                            <th ><strong> <strong>Question</th><td>::</td><td><input type="text" name="Question1" style="width:600px;max-width:600px" /></td>
                                
				</tr>
						  
							<tr>
                                <td ><strong> option 1</strong></td><td>::</td> <td><input type="text" name="option_1" style="width:600px;max-width:600px"/></td>
							</tr>
							<tr>
                                <td><strong>option 2</strong></td><td>::</td><td><input type="text" name="option_2" style="width:600px;max-width:600px" /></td>
							</tr>
                              <tr>
                                  <td><strong>option 3</strong></td><td>::</td><td> <input type="text" name="option_3" style="width:600px;max-width:600px" /></td>
							</tr>
							<tr>
                                <td><strong>option 4</strong></td><td>::</td> <td><input type="text" name="option_4" style="width:600px;max-width:600px" />
                                  
                                </td>
                              </tr>
                              <tr>
							  <td>
                                  <strong>Answer</strong></td><td>::</td><td> <input type="text" name="option_4" style="width:600px;max-width:600px" />
                                  
                                </td>
                              </tr>
                              <tr>
							  <td>
                                
                   <input type="submit" name="submit" value="Upload" align="center" /><input type="reset" name="Submit2" value="Reset" />
                                  
                                  </td></tr>
    
    
    </table>
</form>
    
    
     <?php require_once('footer.php'); ?>
</body>
</html>