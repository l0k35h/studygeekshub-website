<!DOCTYPE html>
<?php require_once('header.php'); ?><!-- #header end -->

		<!-- Page Title
		============================================= -->
		<section id="page-title">

			<div class="container clearfix">
				<h1>Declarations and Initializations</h1>
				
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Post Content
					============================================= -->
					<div class="postcontent nobottommargin clearfix">

						<table class="table">
						  <thead>
							<tr>
							  <th>1. Which of the following statements should be used to obtain a remainder after dividing 3.14 by 2.1 ?</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: rem = 3.14 % 2.1;</td>
							</tr>
							<tr>
							  <td>option 2:: rem = modf(3.14, 2.1);</td>
							</tr>
                              <tr>
							  <td>option 3:: rem = fmod(3.14, 2.1);</td>
							</tr>
							<tr>
							  <td>option 4:: Remainder cannot be obtain in floating point division.
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl1')"  value="answer" id="btn1" >
      <label id="lbl1" hidden >option 3</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>
                        <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>2. What are the types of linkages?</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: Internal and External</td>
							</tr>
							<tr>
							  <td>option 2:: External, Internal and None</td>
							</tr>
                              <tr>
							  <td>option 3:: Internal</td>
							</tr>
							<tr>
							  <td>option 4:: Internal
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl2')"  value="answer" id="btn1" >
      <label id="lbl2" hidden >option 2</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>

                        <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>3. Which of the following special symbol allowed in a variable name?</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: * (asterisk)</td>
							</tr>
							<tr>
							  <td>option 2:: | (pipeline)</td>
							</tr>
                              <tr>
							  <td>option 3:: - (hyphen)</td>
							</tr>
							<tr>
							  <td>option 4:: _ (underscore)
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl3')"  value="answer" id="btn1" >
      <label id="lbl3" hidden >option 4</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>
                        
                        <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>4. Is there any difference between following declarations?</th>
                                <th> 1 :	extern int fun();</th>
                                <th>2 :	int fun();
                                </th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: Both are identical</td>
							</tr>
							<tr>
							  <td>option 2:: No difference, except extern int fun(); is probably in another file</td>
							</tr>
                              <tr>
							  <td>option 3:: int fun(); is overrided with extern int fun();</td>
							</tr>
							<tr>
							  <td>option 4:: None of these
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl4')"  value="answer" id="btn1" >
      <label id="lbl4" hidden >option 2</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>

                         <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>5. How would you round off a value from 1.66 to 2.0?</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: ceil(1.66)</td>
							</tr>
							<tr>
							  <td>option 2:: floor(1.66)</td>
							</tr>
                              <tr>
							  <td>option 3:: roundup(1.66)</td>
							</tr>
							<tr>
							  <td>option 4:: roundto(1.66)
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl5')"  value="answer" id="btn1" >
      <label id="lbl5" hidden >option 1</label> 
                                  <br>
                                  <br>
                                 <a href="Declarations_and_Initializations_page002.php"> <input type="button" value="prev" 
                                                    style="background-color:gry;margin-left:auto;margin-right:auto;display:block;margin-bottom:0%" ></a>
                                  <br>
                                  <a href="Declarations_and_Initializations_page001.php.html"> <input type="button" value="first" 
                                                    style="background-color:gry;margin-left:auto;margin-right:auto;display:block;margin-bottom:0%" ></a>
                                  </td>
							</tr>
						  </tbody>
						</table>
						
                    </div>
                </div>
			</div>
            
        </section>

        
        
		<!-- Footer
		============================================= -->
		<?php require_once('footer.php'); ?>
</body>
</html>