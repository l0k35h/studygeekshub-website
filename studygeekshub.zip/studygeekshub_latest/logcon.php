 
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />

	<!-- Stylesheets
	============================================= -->
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="style.css" type="text/css" />
	<link rel="stylesheet" href="css/swiper.css" type="text/css" />
	<link rel="stylesheet" href="css/dark.css" type="text/css" />
	<link rel="stylesheet" href="css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="css/animate.css" type="text/css" />
	<link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />

	<link rel="stylesheet" href="css/responsive.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<!-- Document Title
	============================================= -->
	<title>main</title>

</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<header id="header" class="full-header dark">

			<div id="header-wrap">

				<div class="container clearfix">


					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="home.php" class="standard-logo" data-dark-logo="images/logo.png"><img src="images/logo.png" alt="Canvas Logo"></a>
						<a href="home.php" class="retina-logo" data-dark-logo="images/logo-dark@2x.png"><img src="images/logo@2x.png" alt="Canvas Logo"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">

						<ul>
							<li><a href="home.php"><div>Home</div></a>
								
							</li>
							<li><a href="error.php"><div>Courses</div></a>
								
							</li>
							<li class="mega-menu"><a href="error.php"><div>PPt</div></a>
								
							</li>
							<li class="mega-menu"><a href="mcq.php"><div>MCQ</div></a>
								
							</li>
							<li class="mega-menu"><a href="main_forum.php"><div>Community</div></a>
								
							</li>
							<li><a href="contact_us.php"><div>Account</div></a>
								
							</li>
							<li class="mega-menu"><a href="future.php"><div>Future</div></a>
								
							</li>
						</ul>

						<!-- Top Search
						============================================= -->
						<div id="top-search">
							<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
							<form action="search.html" method="get">
								<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter..">
							</form>
						</div><!-- #top-search end -->

					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header>
 <?php

 include 'db.php';
$id = $_POST['username'];
$pwd = $_POST['password'];

$sql= "SELECT * from user_data WHERE Username='$id' AND Password='$pwd'";
$result=$conn->query($sql);
if(!$row = $result->fetch_all())
{

  echo "failed";
}
else
{
	 
	echo "Welcome ".$id;

 }

 
         ?>
<footer id="footer"  class="container-fluid text-center">
<div class="container">
<br><br>
	<p>The Ultimate Study Zone &nbsp; | <a href="#" style="color:#000000"> <b>&nbsp;© studygeekshub.com</b></a></p>
<div class="buttons">
  <a href="#"><img src="twitter.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="facebook.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="dribble.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="rss.png"></a><br>
</div>
 <div class="clear"></div>
</footer>
</div>

	<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/plugins.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="js/functions.js"></script>
	</body>
	</html>

