<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>


		<!-- Page Title
		============================================= -->
		<section id="page-title">

			<div class="container clearfix">
				<h1>Future</h1>
				<span>Welcome to Know about Future</span>
				
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="col_full clearfix">

						<h3>Nano Technology</h3>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounce" />Data will update very soon.
                        
                        </p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Ara Project</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="flash" />Data will update very soon</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Artifical Intelligency</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="pulse" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>3-D Printing </h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="shake" />Data will update soon</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="swing" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="tada" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="wobble" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="bounceIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounceInDown" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image"  data-animate="bounceInLeft"/>Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Bounce-In-Right Animation</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="bounceInRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="bounceInUp" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInDown" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeInDownBig" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeInRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInRightBig" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="fadeInUp" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeInUpBig" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="flip" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="flipInX" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="flipInY" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="lightSpeedIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="slideInRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="slideInLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="slideInDown" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="rotateInUpRight"  />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="rotateInUpLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="rotateInDownRight" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="rotateInDownLeft" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="rotateIn" />Data will update soon.</p>

					</div>

					<div class="col_full clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignright notopmargin" alt="Image" title="Image" data-animate="rollIn" />Data will update soon.</p>

					</div>

					<div class="col_full nobottommargin clearfix">

						<div class="fancy-title title-dotted-border">
							<h3>Other Topics</h3>
						</div>

						<p style="font-size: 14px; line-height: 22px;"><img src="images/mac.png" class="alignleft notopmargin" alt="Image" title="Image" data-animate="fadeIn" data-delay="3000" />Data will update soon.</p>

					</div>

				</div>

			</div>

		
		</section>
		<?php require_once('footer.php'); ?>

</body>
</html>