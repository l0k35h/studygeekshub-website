
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>
<?php
include 'db.php';
$first = $_POST['register-form-name'];
$email = $_POST['register-form-email'];
$phone = $_POST['register-form-phone'];

$user = $_POST['register-form-username'];
$pswrd = $_POST['register-form-password'];
$val=$_POST['type'];
$val2=$_POST['type'];
//$pswrd =$_POST['register-form-repassword'];
$imagename=$_FILES["profile"]["name"];
$imagetmp=addslashes (file_get_contents($_FILES['profile']['tmp_name'])); 

$sql = "INSERT INTO user_data (Name,Email,Phone,Username,Password,profile,type,student,img_name,country) VALUES 
('$first','$email','$phone','$user','$pswrd','$imagetmp','$val','$val2','$imagename','$_POST[country]')";
//var_dump($sql);
$result = $conn->query($sql);
echo ("REGISTER SUCCESS");
?>
<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Welcome to studygeekshub!</h1>
  <p class="lead">
   <a href="registration.php" >Click here to login</a>
  </p>

      </div>
    </div>


<?php require_once('footer.php'); ?>
	</body>
	</html>
