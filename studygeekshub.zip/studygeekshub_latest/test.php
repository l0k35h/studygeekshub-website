<?php
$conn=mysqli_connect("localhost","root","","forum");
if (mysqli_connect_errno($conn))
{
print "unable to connect:".mysqli_connect_errno();
	
}
else
{
print "successful!";
}
?>