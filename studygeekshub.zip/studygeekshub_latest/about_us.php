<!DOCTYPE html>
<html>
<head>
<!-- Stylesheets
============================================= -->
<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="css/dark.css" type="text/css" />
<link rel="stylesheet" href="css/font-icons.css" type="text/css" />
<link rel="stylesheet" href="css/animate.css" type="text/css" />
<link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
<link rel="stylesheet" href="css/responsive.css" type="text/css" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<!-- Document Title
============================================= -->
<title>About Me | Studygeekshub</title>
</head>
<body class="stretched">
<!-- Document Wrapper
============================================= -->
<div id="wrapper" class="clearfix">
<!-- Header
============================================= -->
<header id="header" class="full-header">
<div id="header-wrap">
<div class="container clearfix">
<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>
<!-- Logo
============================================= -->
<div id="logo">
<a href="index.html" class="standard-logo" data-dark-logo="images/logo-dark.png"><img src="images/logo.png" alt="Canvas Logo"></a>
</div><!-- #logo end -->
<!-- Primary Navigation
============================================= -->
<nav id="primary-menu">
<ul>
<li><a href=""><div>Home</div></a>
</li>
<li><a href=""><div>Courses</div></a>
</li>
<li class=""><a href="#"><div>PPt</div></a>
</li>
<li class=""><a href="#"><div>MCQ</div></a>
</li>
<li class=""><a href="#"><div>Blog</div></a>
</li>
<li><a href=""><div>Community</div></a>
</li>
<li class=""><a href="#"><div>Future</div></a>
</li>
</ul>
<!-- Top Search
============================================= -->
<div id="top-search">
<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
<form action="search.html" method="get">
<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter..">
</form>
</div><!-- #top-search end -->
</nav><!-- #primary-menu end -->
</div>
</div>
</header><!-- #header end -->
<!-- Page Title
============================================= -->
<section id="page-title" class="page-title-parallax page-title-dark page-title-right" style="padding: 250px 0; background-image: url('images/geeks-unli-header.jpg'); background-size: cover; background-position: center center;" data-stellar-background-ratio="0.2">
<div class="container clearfix">
<h1>Nishant Maurya</h1>
<h1>Abhishek Kumar Thakur</h1>
<h1>Lokesh Pandey</h1>
<h1>Maneesh Kumar</h1>
<h1>Pawan Tiwari</h1>
<span>Founders</span>
</div>
</section><!-- #page-title end -->
<!-- Content
============================================= -->
<section id="content">
<div class="content-wrap">
<div class="container clearfix">
<div class="row clearfix">
<div class="col-md-6">
<h3>Objective</h3>
<p>Learning</p>
</div>
<div class="col-md-6">
<h3>Future Endaevours</h3>
<p>Superb</p>
</div>
</div>
</div>
<div class="section parallax dark bottommargin-lg" style="background-image: url('images/2.jpg'); padding: 100px 0;" data-stellar-background-ratio="0.3">
</div>
<!-- Footer
============================================= -->
<footer id="footer" class="dark">
<div class="container">
<!-- Footer Widgets
============================================= -->
<div class="footer-widgets-wrap clearfix">
<div class="col_two_third">
<div class="col_one_third">
<div class="widget clearfix">
<img src="images/logo2.png" alt="" class="footer-logo">
<p>We believe in <strong>Easy</strong>, <strong>Creative</strong> &amp; <strong>Flexible</strong>
&amp; LEARNING .</p>
<div style="background: url('images/world-map.png') no-repeat center center; background-size: 100%;">
<address>
<strong>Operating From:</strong><br>
LOVELY PROFESSIONAL UNIVERSITY<br>
Punjab , INDIA<br>
</address>
<abbr title="Phone Number"><strong>Phone:</strong></abbr> (91) <br>
<abbr title="Fax"><strong>Fax:</strong></abbr> (91) <br>
<abbr title="Email Address"><strong>Email:</strong></abbr>
</div>
</div>
</div>
</div>
</div><!-- #copyrights end -->
</footer><!-- #footer end -->
</div><!-- #wrapper end -->
<!-- Go To Top
============================================= -->
<div id="gotoTop" class="icon-angle-up"></div>
<!-- External JavaScripts
============================================= -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<!-- Footer Scripts
============================================= -->
<script type="text/javascript" src="js/functions.js"></script>
</body>
</html>