
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>

<?php
$conn=mysqli_connect("localhost","root","","login");
?>


	<section id="page-title">

			<div class="container clearfix">
				<h1>
<?php
				echo $user;
				?>
				</h1>
				<span>Welcome Back !  Administrator</span>
				<ol class="breadcrumb">
					<li><a href="index.html">Home</a></li>
					<li class="active">Dashboard</li>
				</ol>
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

				
                   <div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-plus i-alt"></i></a>
							</div>
                            <h3><a href="about_us.php">ADD NEW Topic</a></h3>
                            
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-user i-alt"></i></a>
							</div>
							<h3><a href="user_profile.php">VIEW PROFILE</a></h3>
							
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							
		                   <div class="fbox-icon">
								<a href="#"><i class="icon-data i-alt"></i></a>
							</div>
							<h3><a href="logout.php">Database</a></h3>
		
						</div>
					</div>
                                       <div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-upload i-alt"></i></a>
							</div>
                            <h3><a href="upload_data.php">upload DATA</a></h3>
                            
						</div>
					</div>
                                       <div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-graph i-alt"></i></a>
							</div>
                            <h3><a href="about_us.php">User Statistics</a></h3>
                            
						</div>
					</div>
                        <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
                            <div class="fbox-icon">
								<a href="#"><i class="icon-off i-alt"></i></a>
							</div>
							<h3><a href="logout.php">LOGOUT</a></h3>
							
						</div>
					</div>
                            
</div>
                    </div>
				

		</section>


		<?php require_once('footer.php'); ?>

</body>
</html>





