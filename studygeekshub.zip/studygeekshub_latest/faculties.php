
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
 <title>The Ultimate Study Companion -  Studygeekshub</title>
 <meta name="description" content="studygeeks hub is  a website for E-learning. The website will provide
information as well as subject materials related to various courses or
streams. It has  an additional feature of community learning
where people can come together to discuss on a particular topic and
share their opinion. Community learning will also enhance the
knowledge and concepts of individual. The website will also provide a
platform for communication between students and experts.">
   <meta name="keywords" content="HTML,CSS,XML,JavaScript,MCQs,PPTs,PDFs,Community,Discussion,Forum,Programming,Engineering">
  <meta name="author" content="Nishant Maurya,Manish Tomar,Abhishek Thakur,Lokesh Pandey,Pawan Tiwari">
  <meta property="og:title" content="Studygeekshub">
  <meta name="robots" content="mcq">
  <meta property="og:site_name" content="studygeekshub">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="en_US">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

<!DOCTYPE html>
<html lang="en-US">
<head>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-5214474402622540",
    enable_page_level_ads: true
  });
</script>

	 <link rel="shortcut icon" type="image/x-icon" href="image/favicon.png" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
 

	<!-- Stylesheets
	============================================= -->
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="style.css" type="text/css" />
	<link rel="stylesheet" href="css/swiper.css" type="text/css" />
	<link rel="stylesheet" href="css/dark.css" type="text/css" />
	<link rel="stylesheet" href="css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="css/animate.css" type="text/css" />
	<link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
    <link rel="stylesheet" href="style_1.css" type="text/css" />
	<link rel="stylesheet" href="css/responsive.css" type="text/css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<!-- Document Title
	============================================= -->
	<title>main</title>

</head>

<body class="stretched">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-97814964-1', 'auto');
  ga('send', 'pageview');

</script>
	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<header id="header" class="full-header dark">

			<div id="header-wrap">

				<div class="container clearfix">

               <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="index.php" class="standard-logo" data-dark-logo="image/logo.png"><img src="image/logo.png" alt="Canvas Logo"></a>
						<a href="index.php" class="retina-logo" data-dark-logo="image/logo-dark@2x.png"><img src="image/logo@2x.png" alt="Canvas Logo"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">

						<ul>
							<li><a href="index.php"><div>Home</div></a>
								
							</li>
							<li><a href="course.php"><div>Courses</div></a>
								
							</li>
							
							<li class="mega-menu"><a href="mcq.php"><div>MCQ</div></a>
								
							</li>
							<li class="mega-menu"><a href="main_forum.php"><div>Community</div></a>
								
							</li>

							<li class="mega-menu"><a href="login_validate.php" ><div>Account</div></a></li>
							<li class="mega-menu"><a href="about_us.php"><div>About Us</div></a>
								
							</li>
						</ul>



						<!-- Top Search
						============================================= -->
						<div id="top-search">
							<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
							<form action="search.php" method="get">
								<input type="text" name="q" class="form-control"  placeholder="Type &amp; Hit Enter..">
							</form>
						
						</div><!-- #top-search end -->

					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->



<div class="section">
					<div class="container clearfix">

						<div class="row topmargin-sm">

							<div class="heading-block center">
								<h3>Meet Our EXPERTS</h3>
							</div>

							<div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="1.jpg" alt="PROF. BHUPINDER VERMA">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>PROF. BHUPINDER VERMA</h4><span>PROFESSOR, DEPARTMENT OF ELECTRONICS & ELECTRICAL ENGINEERING</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>

							<div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="2.jpg" alt="MS. DOLONCHAPA PRABHAKAR">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>MS. DOLONCHAPA PRABHAKAR</h4><span>PROFESSOR, DEPARTMENT OF HYDRAULIC ENGINEERING</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>


							<div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="3.JPG" alt="MR. SANJAY JINDAL">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>MR. SANJAY JINDAL</h4><span>ASSISTANT PROFESSOR, DEPARTMENT OF MANAGEMENT</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>

                                                       <div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="4.jpg" alt="MS. MANDEEP KAUR">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>MS. MANDEEP KAUR</h4><span>PROFESSOR, DEPARTMENT OF CIVIL ENGINEERING</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>

<div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="5.JPG" alt="MR. MIHIR LAL">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>MR. MIHIR LAL</h4><span>PROFESSOR, DEPARTMENT OF GEOTECH AND FOUNDATION ENGINEERING</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>
<div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="6.JPG" alt="Aditya Khamparia">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>Aditya Khamparia</h4><span>Assistant Professor, Department of Computer Science</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>

<div class="col-md-3 col-sm-6 bottommargin">

								<div class="team">
									<div class="team-image">
										<img src="7.JPG" alt="Dr. Lovi Raj Gupta">
									</div>
									<div class="team-desc team-desc-bg">
										<div class="team-title"><h4>Dr. Lovi Raj Gupta</h4><span> Executive Dean, Faculty of Technology & Sciences</span></div>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

							</div>


						</div>

					</div>
				</div>






<!-- Footer
		============================================= -->
<footer id="footer"  class="container-fluid text-center">
<div class="container">
<br><br>
	<p>The Ultimate Study Zone &nbsp; | <a href="#" style="color:#000000"> <b>&nbsp;© studygeekshub.com</b></a></p>
<div class="buttons">
  <a href="https://twitter.com/studygeekshub"><img src="twitter.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="https://www.facebook.com/studygeekshub/"><img src="facebook.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="#"><img src="google.png"></a>&nbsp;&nbsp;&nbsp;&nbsp;
  
</div>
 <div class="clear"></div></div>
</footer>


	<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/plugins.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="js/functions.js"></script>
</body>
</html>





