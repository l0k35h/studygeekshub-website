<!DOCTYPE html>
<?php require_once('header.php'); ?><!-- #header end -->
		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">
				<div class="heading-block center">
							<h2>PROGRAMMING IN C</h2>
						</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
                            <h3><a href="introduction_of_c_programming_in_c_it.php">INTRODUCTION of C </a></a></h3>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3><a href="Identifiers_Keywords_Data_types_programming_in_c_it.php">Identifiers ,  Keywords & Data types</a></h3>
                            <br>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="Constant_Variable_Expression_programming_in_c_it.php">Constant , Variable , Expression</a></h3>
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-stack i-alt"></i></a>
							</div>
							<h3><a href="Formatted_and_Unformatted_Input_Output_Functions_programming_in_c_it.php">Formatted and Unformatted Input/Output Functions</a></h3>
                            <br>
                            <br>
                            <br>
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="Operators_programming_in_c_it.php">Operators</a></h3>
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="Control_structures_programming_in_c.php">Control structures</a></h3>                       
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="Jump_statements_programming_in_c_it.php"> Jump statements</a></h3>
							<br>
                            <br>
                            <br>
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="Introduction_to_Functions_programming_in_c_it.php">Introduction to Functions</a> </h3>
							
						</div>
					</div>
                    <div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="Function_Call_programming_in_c_it.php">Function Call</a></h3>
                                   <br>                                                 
						</div>
					</div>
                    
                     <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="Recursive_function_Math_Library_Functions_programming_in_c_it.php">Recursive function Math Library Functions
                                    </a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="Recursive_function_programming_in_c_it.php">Recursive function</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
                            <br>
                            
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
                            <br>
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
                            <h3><a href="">Data Coming Soon</a></h3>
                            <br>
						</div>
					</div>
                <div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
                            <h3><a href="">Data Coming Soon</a></a></h3>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
                            <br>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Data Coming Soon</a></h3>
						</div>
					</div>
				</div>
 					
			</div>

		</section><br><br><!-- #content end -->
        
		<?php require_once('footer.php'); ?>
</body>
</html>