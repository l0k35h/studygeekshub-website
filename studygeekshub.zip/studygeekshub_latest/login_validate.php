<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>
<head>
</head>
<body>
<?php
		
    if ($_SESSION["Login"]!== "YES") 
        {
 
           header('location:registration.php');   

        }  


       elseif ($_SESSION["Login"]!== "NO") 
{
  header('location:user_dashboard.php');
          
}

    ?>
   </body>
   </html>