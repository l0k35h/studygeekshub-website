<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>





		<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Website is under maintenance.</h1>
  <p class="lead">
    Thanks for your patience, we'll be back shortly..
  </p>


<div class="row">
<div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div>
<div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div><div class="col-md-4"><img src="image/img3.jpeg" class="img-circle" width="50" height="50">UserName<br>
                                    Location</div>
</div>
                                


      </div>


		<?php require_once('footer.php'); ?>
</body>
</html>