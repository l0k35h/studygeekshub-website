<!DOCTYPE html>
<?php require_once('header.php'); ?>

		<!-- Page Title
		============================================= -->
		<section id="page-title">

			<div class="container clearfix">
				<h1>Declarations and Initializations</h1>
				
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Post Content
					============================================= -->
					<div class="postcontent nobottommargin clearfix">

						<table class="table">
						  <thead>
							<tr>
							  <th>6. By default a real number is treated as a</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: float</td>
							</tr>
							<tr>
							  <td>option 2:: double</td>
							</tr>
                              <tr>
							  <td>option 3:: long double</td>
							</tr>
							<tr>
							  <td>option 4:: far double
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl1')"  value="answer" id="btn1" >
      <label id="lbl1" hidden >option 2</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>
                        <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>7. When we mention the prototype of a function?</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: Defining</td>
							</tr>
							<tr>
							  <td>option 2:: Declaring</td>
							</tr>
                              <tr>
							  <td>option 3:: Prototyping</td>
							</tr>
							<tr>
							  <td>option 4:: Calling
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl2')"  value="answer" id="btn1" >
      <label id="lbl2" hidden >option 2</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>

                        <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>8. Guess the Output.<br>
#include<stdio.h><br>
int main()<br>
{<br>
    enum status { pass, fail, atkt};<br>
    enum status stud1, stud2, stud3;<br>
    stud1 = pass;<br>
    stud2 = atkt;<br>
    stud3 = fail;<br>
    printf("%d, %d, %d\n", stud1, stud2, stud3);<br>
    return 0;<br>
}</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: 0, 1, 2</td>
							</tr>
							<tr>
							  <td>option 2:: 1, 2, 3</td>
							</tr>
                              <tr>
							  <td>option 3:: 0, 2, 1</td>
							</tr>
							<tr>
							  <td>option 4:: 1, 3, 2
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl3')"  value="answer" id="btn1" >
      <label id="lbl3" hidden >option 3</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>
                        
                        <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>9. Which of the following declarations are correct?</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: short i=10;</td>
							</tr>
							<tr>
							  <td>option 2:: static i=10;</td>
							</tr>
                              <tr>
							  <td>option 3:: unsigned i=10;</td>
							</tr>
							<tr>
							  <td>option 4:: All
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl4')"  value="answer" id="btn1" >
      <label id="lbl4" hidden >option 4</label>
                                </td>
                                
                                
							</tr>
						  </tbody>
						</table>

                         <br>
                        
                        <table class="table">
						  <thead>
							<tr>
							  <th>10. To declare a 3 dimension array using pointers, which of the following is the correct syntax:</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <td>option 1:: char *a[][];</td>
							</tr>
							<tr>
							  <td>option 2:: char **a[];</td>
							</tr>
                              <tr>
							  <td>option 3:: char ***a;</td>
							</tr>
							<tr>
							  <td>option 4:: All of the mentioned
                                  <br>
                                  <br>
<script type="text/javascript">
function toggle_visibility(id) 
{
    var e=document.getElementById(id);
    if(e.style.display == 'block')
        e.style.display = 'none';
    else
        e.style.display = 'block';
}
</script>
                                  
         <input type="button" onclick="toggle_visibility('lbl5')"  value="answer" id="btn1" >
      <label id="lbl5" hidden >option 1</label> 
                                  <br>
                                  <br>
                                        <a href="Declarations_and_Initializations_page001.php"> <input type="button" value="prev" 
                                                    style="background-color:gry;margin-left:auto;margin-right:auto;display:block;margin-bottom:0%"></a>
                                    <br>
                                        <a href="Declarations_and_Initializations_page003.php"> <input type="button" value="next" 
                                                    style="background-color:gry;margin-left:auto;margin-right:auto;display:block;margin-bottom:0%" ></a>
                                    
                                  </td>
							</tr>
						  </tbody>
						</table>
						
                    </div>
                </div>
			</div>
            
        </section>

        
        
		<!-- Footer
		============================================= -->
		<?php require_once('footer.php'); ?>
</body>
</html>