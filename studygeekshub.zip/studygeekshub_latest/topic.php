<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>

<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Community Portal!</h1>

  <p class="lead">
   
  </p>



<?php require_once('footer.php'); ?>

</body>
</html>
