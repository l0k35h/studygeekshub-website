<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>




		<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Website is under maintenance.</h1>
  <p class="lead">
    Thanks for your patience, we'll be back shortly..
  </p>

      </div>

		<?php require_once('footer.php'); ?>

</body>
</html>