<?php
$num=1;
foreach ($_FILES["pictures"]["error"] as $key => $error) {

    if ($error == UPLOAD_ERR_OK) {
        $tmp_name = $_FILES["pictures"]["tmp_name"][$key];
        // basename() may prevent filesystem traversal attacks;
        // further validation/sanitation of the filename may be appropriate
        $name = basename($_FILES["pictures"][$num][$key]);
        $num++;
        var_dump($name);
        move_uploaded_file($tmp_name, "uploads/$name");
    }
}
?>


