
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>

<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Start a New Discussion !</h1>
  <p class="lead">
    We provide our users to add new discussion topics of their choice.
  </p>

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover table-condensed">

<tr>


<form id="form1" name="form1" method="post" action="add_topic.php" enctype="multipart/form-data">

<td>
<table class="table table-striped table-bordered table-hover table-condensed"bgcolor="#FFFFFF">
<tr>
<td colspan="3" bgcolor="#E6E6E6"><strong>Create New Topic</strong> </td>
</tr>
<tr>
<td width="14%"><strong>Topic</strong></td>
<td width="2%">:</td>
<td width="84%"><input name="topic" type="text" id="topic" size="50" /></td>
</tr>
<tr><td>	
<strong>Category</strong></td>
<td>:</td>
<td><select name="category">
<option value="category">Building and Managing a Website</option>
<option value="name2">name2</option>
<option value="name3">name3</option>
<option value="name4">name4</option>
</select><br></td>
</tr>
</div>
<tr>
<td width="14%"><strong>Description</strong></td>
<td width="2%">:</td>
<td>
<textarea  name="detail" id="detail" rows="4" cols="50" placeholder="Describe your post or query...">

</textarea></td>
</tr>

<tr>
<td><strong>Screenshots(if any)</strong></td>
<td>:</td>
<td><input type="file" name="myimage"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>

<td><input type="submit"  value="submit" /> 

<input type="reset" name="Submit2" value="Reset" /></td>
</tr>
</table>
</td>


</form>

</tr>
</table>
</div>
<?php require_once('footer.php'); ?>

</body>
</html>
