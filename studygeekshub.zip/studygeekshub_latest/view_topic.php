<html>
<head>
</head>
<body>
<?php

$conn=mysqli_connect("localhost","root","","forum");
if (mysqli_connect_errno($conn))
{
print "unable to connect:".mysqli_connect_errno();
	
}

// get value of id that sent from address bar 
$sql="SELECT * FROM forum_question WHERE id='2'";
$result=$conn->query($sql);
$row=$result->fetch_all();echo $row[2];
?>

<table width="400" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor="1" bgcolor="#FFFFFF">
<tr>
<td bgcolor="#F8F7F1"><strong><? echo $row[0]; ?></strong></td>
</tr>

<tr>
<td bgcolor="#F8F7F1"><? echo $row[1]; ?></td>
</tr>

<tr>
<td bgcolor="#F8F7F1"><strong>By :</strong> <? echo $row[3]; ?> <strong>Email : </strong><? echo $row['email'];?></td>
</tr>

<tr>
<td bgcolor="#F8F7F1"><strong>Date/time : </strong><? echo $row['datetime']; ?></td>
</tr>
</table></td>
</tr>
</table>
<BR>



</body>
</html>