<!DOCTYPE html>
<?php require_once('header.php'); ?><!-- #header end -->
		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">
				<div class="heading-block center">
							<h2>IT</h2>
						</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
                            <h3><a href="">GRAPHIC TOOLS</a></a></h3>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3><a href="programming_in_c_it.php">PROGRAMMING IN C</a></h3>
                            <br>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">COMPUTER NETWORKS</a></h3>
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-stack i-alt"></i></a>
							</div>
							<h3><a href="">COMPUTER ORGANIZATION AND DESIGN</a></h3>
                            <br>
                            <br>
                            <br>
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">DIGITAL ELECTRONICS</a></h3>
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">ELECTRONIC DEVICES</a></h3>                       
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">DATABASE MANAGEMENT SYSTEM</a></h3>
							<br>
                            <br>
                            <br>
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">MICROPROCESSORS AND ITS APPLICATIONS</a> </h3>
							
						</div>
					</div>
                    <div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">OBJECT ORIENTED PROGRAMMING</a></h3>
                                   <br>                                                 
						</div>
					</div>
                    
                     <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">SOFTWARE ENGINEERING</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">INFORMATION SECURITY</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">FUNDAMENTALS OF WEB PROGRAMMING</a></h3>
                            <br>
                            
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">MULTIMEDIA SYSTEM</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">VISUAL PROGRAMMING</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">DATA STRUCTURES</a></h3>
                            <br>
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">OPERATING SYSTEM</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">ENTERPRISE RESOURSE PLANNING</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
                            <h3><a href="">ANALYTICAL SKILLS</a></h3>
                            <br>
						</div>
					</div>
                <div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
                            <h3><a href="">ALGORITHM DESIGN AND ANALYSIS</a></a></h3>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3><a href="">PROGRAMMING IN JAVA</a></h3>
                            <br>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">FORMAL LANGUAGES AND AUTOMATION THEORY</a></h3>
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-stack i-alt"></i></a>
							</div>
							<h3><a href="">Introduction to Information Theory and Applications</a></h3>
                            <br>
                            <br>
                            <br>
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">BASIC FINANCIAL MANAGEMENT</a></h3>
                            <br>
                            <br>
                            
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">ANALYSIS AND DESIGN OF INFORMATION SYSTEMS</a></h3>                       
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">COMPUTER GRAPHICS AND VISUALISATION</a></h3>
							<br>
                            <br>
                            <br>
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">COMPUTER BASED OPTIMIZATION TECHNIQUES</a> </h3>
							
						</div>
					</div>
                    <div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">SYSTEM SOFTWARE</a></h3>
                                   <br>                                                 
						</div>
					</div>
                    
                     <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Search Engine Optimization</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">ARTIFICIAL INTELLIGENCE</a></h3>
                            <br>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">MANAGING INNOVATION AND ENTREPRENEURSHIP</a></h3>
                            <br>
                            
						</div>
					</div>
            <div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-screen i-alt"></i></a>
							</div>
                            <h3><a href="">OPEN SOURCE TECHNOLOGIES</a></a></h3>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-eye i-alt"></i></a>
							</div>
							<h3><a href="">CALCULUS</a></h3>
                            <br>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">MECHANICS</a></h3>
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-stack i-alt"></i></a>
							</div>
							<h3><a href="">CELL BIOLOGY</a></h3>
                            <br>
                            <br>
                            <br>
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">ELECTRICITY AND MAGNETISM</a></h3>
                            <br>
                            <br>
                            <br>
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">DIFFERENTIAL EQUATIONS</a></h3>                       
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">MICROBIOLOGY</a></h3>
							<br>
                            <br>
                            <br>
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">FUNDAMENTALS OF BIOCHEMISTRY</a> </h3>
							
						</div>
					</div>
                    <div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-text-width i-alt"></i></a>
							</div>
							<h3><a href="">ALGEBRA</a></h3>
                                   <br>      
                            <br>
						</div>
					</div>
                    
                     <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">WAVES AND OPTICS</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">INTRODUCTION TO IMMUNOLOGY</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">ELEMENTS OF MODERN PHYSICS</a></h3>
                            <br>
                            
						</div>
					</div>
                  <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">BIOANALYTICAL TECHNIQUES</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">CLOUD COMPUTING</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">FUNDAMENTALS OF MOLECULAR BIOLOGY</a></h3>
                            <br>
                            
						</div>
					</div>
                <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">MULTIVARIATE CALCULUS</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">Quantum and Atomic Physics</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Solid State Physics</a></h3>
                            <br>
                            
						</div>
					</div>
<div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">FOOD BIOTECHNOLOGY</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">PRINCIPLES OF GENETICS</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Molecular Genetics</a></h3>
                            <br>
                            
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">FUNDAMENTALS OF GENETIC ENGINEERING</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">INDUSTRIAL BIOTECHNOLOGY</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">ENZYMOLOGY AND ENZYME TECHNOLOGY</a></h3>
                            <br>
                            
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">PHARMACEUTICAL BIOTECHNOLOGY</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">GENOMICS AND PROTEOMICS</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Nanobiotechnology</a></h3>
                            <br>
                            
						</div>
					</div>
                    <div class="clear"></div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">STEM CELL TECHNOLOGY</a></h3>
							
						</div>
					</div>
                   <div class="col_one_third nobottommargin">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-tint i-alt"></i></a>
							</div>
							<h3><a href="">ANIMAL BIOTECHNOLOGY</a></h3>
							
						</div>
					</div>
                    <div class="col_one_third col_last">
						<div class="feature-box fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="icon-beaker i-alt"></i></a>
							</div>
							<h3><a href="">Molecular Biology of Eukaryotic Systems</a></h3>
                            <br>
                            
						</div>
					</div>

					<div class="clear"></div><div class="line"></div>

					
				</div>
 					
			</div>

		</section><br><br><!-- #content end -->
        
		<?php require_once('footer.php'); ?>
</body>
</html>