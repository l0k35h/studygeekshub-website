<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php require_once('header.php'); ?>
<section id=content>
 <div class="bd-pageheader">
      <div class="container">
      <br>
        
  <h1>Welcome to our Community Portal!</h1>

      </div>
    </div><?php

$conn=mysqli_connect("localhost","root","","forum");
if (mysqli_connect_errno($conn))
{
print "unable to connect:".mysqli_connect_errno();
	
}
$imagename=$_FILES["myimage"]["name"];
$imagetmp=addslashes (file_get_contents($_FILES['myimage']['tmp_name']));	

$datetime=date("d/m/y h:i:s"); //create date time

$sql="INSERT INTO forum_question(topic,category, detail, datetime,screenshot,img_name)VALUES('$_POST[topic]','$_POST[category]','$_POST[detail]','$datetime','$imagetmp','$imagename')";	

if(!mysqli_query($conn,$sql))
{
	die(print'error:'.mysqli_error());

}
print "recorded!!";

mysqli_close($conn);
echo "<a href=main_forum.php>View your topic</a>";

?>
<?php require_once('footer.php'); ?>
</body>
</html>